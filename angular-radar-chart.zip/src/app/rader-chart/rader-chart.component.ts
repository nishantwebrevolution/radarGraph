import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'radar-chart',
  templateUrl: './rader-chart.component.html',
  styleUrls: ['./rader-chart.component.css']
})
export class RaderChartComponent implements OnInit {

  height = 600;
  width = 600;
  polygon = 7;
  points:Points[]=[];


  innerCircle = {cx:0,cy:0,cr:2};
  outerCircle = {cx:0,cy:0,cr:2};
 

  constructor() { }

  ngOnInit() {
      this.createCircle();
      this.coordinates();
  }

  createCircle()
  {
    this.innerCircle.cx = this.width/2;
    this.innerCircle.cy = this.height/2;
    this.innerCircle.cr = 10;
    this.outerCircle.cx = this.width/2;
    this.outerCircle.cy = this.height/2;
    this.outerCircle.cr = this.height/2>10 ?(this.height/2)-10:this.height/2;
  }

  getAngle()
  {
    return  360/this.polygon;
    
    
  }

  coordinates()
  {
    /*x(t) = r cos(t) + j
    y(t) = r sin(t) + k*/
    let points={x:0,y:0};

    let x=this.outerCircle.cr * (Math.cos(this.getAngle()))
    let y=this.outerCircle.cr * (Math.cos(this.getAngle()))
    this.points.push(new Points(x+300,y+300));
    x=this.innerCircle.cr * (Math.cos(this.getAngle()))
    y=this.innerCircle.cr * (Math.cos(this.getAngle()))
    this.points.push(new Points(x+300,y+300));
    this.points.push(new Points(300,300));

  }

}

export class Points
{
  public x:number;
  public y:number;
  constructor(x:number,y:number)
  {
    this.x =x;
    this.y = y;
  }
  
} 
